﻿namespace minimal_school_system.JWT
{
    public interface IJwtHandler
    {
        public string GenerateJwtToken();
    }
}
