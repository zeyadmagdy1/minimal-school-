﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;

namespace minimal_school_system.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }

        [Required]
        public string Name { get; set; }

        [MaxLength(20)]
        public string Username { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }
        
        public Subject Subject { get; set; }

        public int SubjectId { get; set; }
        

    




    }
}
