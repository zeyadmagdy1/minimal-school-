﻿using System.ComponentModel.DataAnnotations;

namespace minimal_school_system.Models
{
    public class Subject
    {

        [Key]
        public int SubjectId { get; set; }

        public string SubjectName { get; set; }

        public List<Student> Students { get; set; }



        

    }
}
