﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using minimal_school_system.Data;
using minimal_school_system.Models;
using minimal_school_system.SubjectRepo;

namespace minimal_school_system.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubjectController : ControllerBase
    {
        private readonly ISubjectReposatory _context;
        public SubjectController(ISubjectReposatory context)
        {
            _context = context;
        }


        [HttpPost]
        public IActionResult AddSubject(SubjectDto subjectDto)
        {
            _context.AddSubject(subjectDto);
            return Ok();
        }

        [HttpGet]
        public IActionResult GetSubjects()
        {
            var result= _context.GetSubjects();
            return Ok(result);
        }


        
    }
}
