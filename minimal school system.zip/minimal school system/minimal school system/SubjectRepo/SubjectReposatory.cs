﻿using Microsoft.EntityFrameworkCore;
using minimal_school_system.Data;
using minimal_school_system.Models;

namespace minimal_school_system.SubjectRepo
{
    public class SubjectReposatory : ISubjectReposatory
    {
        private readonly AppDbContext _context;
        public SubjectReposatory(AppDbContext context) 
        {
            _context = context;
        }
        public void AddSubject(SubjectDto subject)
        {
            Subject subject1 = new Subject { 
                SubjectName = subject.Name,
            };
            _context.subjects.Add(subject1);
            _context.SaveChanges();
        }

        public List<Subject> GetSubjects()
        {
            return _context.subjects.ToList();
        }
    }
}
