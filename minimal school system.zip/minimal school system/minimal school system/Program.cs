
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using minimal_school_system.Data;
using minimal_school_system.JWT;
using minimal_school_system.Reposatory_Patterns;
using minimal_school_system.SubjectRepo;
using System.Text;

namespace minimal_school_system
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            var connection = builder.Configuration.GetConnectionString("DefultConnection");

            builder.Services.AddDbContext<AppDbContext>(option => option.UseSqlServer(connection));

            builder.Services.AddScoped<IStudentReposatory,StudentReposatory>();

            builder.Services.AddScoped<ISubjectReposatory,SubjectReposatory>();
            builder.Services.AddScoped<IJwtHandler,JwtHandler>();


            builder.Services.AddAuthentication(options => {
                options.DefaultAuthenticateScheme=JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options => options.TokenValidationParameters =new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = builder.Configuration[("JWT:Issuer")],
                ValidateAudience = true,
                ValidAudience = builder.Configuration[("JWT:Audience")],
                ValidateIssuerSigningKey = true,
                IssuerSigningKey= new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:key"]))
            });
            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseAuthentication();    

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
