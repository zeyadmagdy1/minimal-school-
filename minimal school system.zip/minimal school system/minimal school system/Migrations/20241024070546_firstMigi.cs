﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace minimal_school_system.Migrations
{
    /// <inheritdoc />
    public partial class firstMigi : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "subjects",
                columns: table => new
                {
                    SubjectId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubjectName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_subjects", x => x.SubjectId);
                });

            migrationBuilder.CreateTable(
                name: "instractorrs",
                columns: table => new
                {
                    InstractorrId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InstractorName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InstractorSalary = table.Column<int>(type: "int", nullable: false),
                    SubjectId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_instractorrs", x => x.InstractorrId);
                    table.ForeignKey(
                        name: "FK_instractorrs_subjects_SubjectId",
                        column: x => x.SubjectId,
                        principalTable: "subjects",
                        principalColumn: "SubjectId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "students",
                columns: table => new
                {
                    StudentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectId = table.Column<int>(type: "int", nullable: false),
                    InstractorrId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_students", x => x.StudentId);
                    table.ForeignKey(
                        name: "FK_students_instractorrs_InstractorrId",
                        column: x => x.InstractorrId,
                        principalTable: "instractorrs",
                        principalColumn: "InstractorrId",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_students_subjects_SubjectId",
                        column: x => x.SubjectId,
                        principalTable: "subjects",
                        principalColumn: "SubjectId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_instractorrs_SubjectId",
                table: "instractorrs",
                column: "SubjectId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_students_InstractorrId",
                table: "students",
                column: "InstractorrId");

            migrationBuilder.CreateIndex(
                name: "IX_students_SubjectId",
                table: "students",
                column: "SubjectId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "students");

            migrationBuilder.DropTable(
                name: "instractorrs");

            migrationBuilder.DropTable(
                name: "subjects");
        }
    }
}
