﻿using minimal_school_system.Models;

namespace minimal_school_system.Reposatory_Patterns
{
    public interface IStudentReposatory
    {
        public List<StudentDto> GetStudents();

        public void AddStudent (StudentDto student);

        public Student GetStudnet(int id);


        public void DeleteStudent(int id);  


        public void UpdateStudent (int id , string username);
       
           
    }
}
